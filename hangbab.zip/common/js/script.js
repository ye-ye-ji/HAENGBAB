$(function(){
    var header = $('#header'),
        gnb = $('#header #gnb'),
        oneBt = $('#header #gnb > li'),
        dep2 = $('#header #gnb > li > ul.depth2'),
        depBg = $('#header .depth2Bg'),
        gnbNum = -1;

        gnb.mouseenter(function(){
            dep2.fadeIn(200);    
            depBg.fadeIn(100);
        });
         
        gnb.mouseleave(function(){
            dep2.fadeOut(100);    
            depBg.fadeOut(200);
        });

        dep2.each(function(i){      
            dep2.mouseenter(function(){
                gnbNum = i;
                $(this).eq(gnbNum).parent('li').addClass('on');
            });
            dep2.mouseleave(function(){
                $(this).parent('li').removeClass('on');
            });
        });
        
    var swiper = new Swiper('.swiper-container', {
        slidesPerView: 2.5,
        spaceBetween: 40,
        centeredSlides:true,
        loop: true,
        loopFillGroupWithBlank: true,
        pagination: {
          el: '.swiper-pagination',
          clickable: true,
        },
        navigation: {
          nextEl: '.swiper-button-next',
          prevEl: '.swiper-button-prev',
        },
      });
});
